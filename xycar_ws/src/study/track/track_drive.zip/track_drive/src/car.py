from dataclasses import dataclass

class Car:
    width=30
    height=60
    lf=18
    ld=14
    

