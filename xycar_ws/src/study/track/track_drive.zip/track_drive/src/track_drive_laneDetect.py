#!/usr/bin/env python
# -*- coding: utf-8 -*- 1
#=============================================
# 본 프로그램은 자이트론에서 제작한 것입니다.
# 상업라이센스에 의해 제공되므로 무단배포 및 상업적 이용을 금합니다.
# 교육과 실습 용도로만 사용가능하며 외부유출은 금지됩니다.
#=============================================
# 함께 사용되는 각종 파이썬 패키지들의 import 선언부
#=============================================
import numpy as np
import cv2, rospy, time, math, os
from sensor_msgs.msg import Image
from std_msgs.msg import Int32MultiArray
from xycar_msgs.msg import xycar_motor
from sensor_msgs.msg import LaserScan
from cv_bridge import CvBridge
from ar_track_alvar_msgs.msg import AlvarMarkers
import importlib.util
import matplotlib.pyplot as plt
import glob
from laneDetector import LaneDetecter
bridge = CvBridge() 

def cam_exposure(value):
    command = 'v4l2-ctl -d /dev/videoCAM -c exposure_absolute=' + str(value)
    os.system(command)

def usbcam_callback(data):
    global image
    image = bridge.imgmsg_to_cv2(data, "bgr8")


image = np.empty(shape=[0])  # 카메라 이미지를 담을 변수

def start():

    global motor, ultra_msg, image 

    cam_exposure(100)  # 카메라의 Exposure 값을 변경

    rospy.init_node('Track_Driver')
    rospy.Subscriber("/usb_cam/image_raw/",Image,usbcam_callback, queue_size=1)
   
    rospy.wait_for_message("/usb_cam/image_raw/", Image)
    print("Camera Ready --------------")

    ld =LaneDetecter()



    while not rospy.is_shutdown():
        ld.detect_lanes(image.copy(),'test.jpg')
        ld.find_next_point()
        cv2.imshow('test',image)
        cv2.waitKey(1)
        
        

#threshold  수정하기
#이동평균 angle 추가하기


if __name__ == '__main__':
    start()
