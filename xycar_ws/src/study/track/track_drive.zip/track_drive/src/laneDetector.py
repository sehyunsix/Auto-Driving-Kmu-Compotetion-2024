#!/usr/bin/env python

import cv2
import numpy as np
import os
import numpy as np
import matplotlib.pyplot as plt
from copy import deepcopy
from utils import set_save_files, save_dir, ensure_dir, get_save_files
from dataclasses import dataclass
win_name = "scanning"
img = cv2.imread("/home/xytron/xycar_ws/data/perspective_view/frame0831.jpg")
rows, cols = img.shape[:2]
draw = img.copy()
perspective_correction = None
perspective_correction_inv = None
perspective_trapezoid = None
warp_size = None
orig_size = None
left_fit_avg = None
right_fit_avg = None
MIN_DETECTIONS = 8
MAX_DETECTIONS = 10



class HistLanes:
    def __init__(self, x_left, x_right, left_confidence, right_confidence):
        self.x_left = x_left
        self.x_right = x_right
        self.left_confidence = left_confidence
        self.right_confidence = right_confidence

# Single lane line
@dataclass(repr=True)
class Line:
    lane_indexes =None
    # pixel positions
    x = None
    y = None

    # Fit a second order polynomial to each
    fit = None
    # Plotting parameters
    fitx = []

    # Histogram
    hist_x = None

    def __repr__(self) -> str:
        return (
            self.__class__.__qualname__ + f"(lane_indedxes={self.lane_indexes!r}\nx={self.x!r}\n "
            f"y={self.y!r}\nfit={self.fit!r}\nfitx={self.fitx!r}\nhist_x={self.hist_x!r})\n"
        )
    


# Data collected during the sliding windows phase
class SlideWindow:
    left = Line()
    right = Line()
    left_center=Line()
    right_center=Line()
    main_center=Line()
    hist = None
    left_avg = None
    right_avg = None
    ploty = None


    def __init__(self, hist, left_lane_indexes, right_lane_indexes, non_zero_x, non_zero_y):
        self.left.lane_indexes = np.concatenate(left_lane_indexes)
        self.right.lane_indexes = np.concatenate(right_lane_indexes)
        self.left.hist_x = hist.x_left
        self.right.hist_x = hist.x_right
        
        self.left.x = non_zero_x[self.left.lane_indexes]
        self.left.y = non_zero_y[self.left.lane_indexes]
        self.right.x = non_zero_x[self.right.lane_indexes]
        self.right.y = non_zero_y[self.right.lane_indexes]

    def plot_lines(self, img, color_left=(0, 255, 255), color_right=(0, 255, 255)):
        left = []
        right = []
        for i in range(0, len(self.ploty)):
            left.append((self.left.fitx[i], self.ploty[i]))
            right.append((self.right.fitx[i], self.ploty[i]))

        cv2.polylines(img, np.int32([left]), False, color_left)
        cv2.polylines(img, np.int32([right]), False, color_right)

        return img

class LaneDetecter:
    middle=319
    lookahead=240
    lane_width = 186

    left_lanes=[]
    right_lanes=[]

    width = 640 # 두 좌우 거리간의 최대값이 서류의 폭
    height = 480  # 두 상하 거리간의 최대값이 서류의 높이
    
    pts1 = np.float32([[241,267],[479,261],[633,314],[81,325]])

    # 변환 후 4개 좌표
    pts2 = np.float32([[width*0.2, 0], [width*0.8, 0],
                        [width*0.8, height-1], [width*0.2, height-1]])
    # 변환 행렬 계산 
    perspective_correction= cv2.getPerspectiveTransform(pts1, pts2)
    perspective_correction_inv =cv2.getPerspectiveTransform(pts2, pts1)
    perspective_trapezoid=None
    perspective_dest=None
    left_fit_avg = None
    right_fit_avg = None
    sw=None
    warp_size=None
    orig_size=None

    #image
    wraped_lane=None

    
    # def compute_perspective(self,width, height, pt1, pt2, pt3, pt4):
    #     # global perspective_trapezoid, perspective_dest
    #     self.perspective_trapezoid = [(pt1[0], pt1[1]), (pt2[0], pt2[1]), (pt3[0], pt3[1]), (pt4[0], pt4[1])]
    #     src = np.float32([pt1, pt2, pt3, pt4])
    #     # widest side on the trapezoid
    #     x1 = pt1[0]
    #     x2 = pt4[0]
    #     # height of the trapezoid
    #     y1 = pt1[1]
    #     y2 = pt2[1]
    #     h = y1 - y2
    #     # The destination is a rectangle with the height of the trapezoid and the width of the widest side
    #     dst = np.float32([[x1, h], [x1, 0], [x2, 0], [x2, h]])
    #     self.perspective_dest = [(x1, y1), (x1, y2), (x2, y2), (x2, y1)]

     
    #     self.perspective_correction = cv2.getPerspectiveTransform(src, dst)
    #     self.perspective_correction_inv = cv2.getPerspectiveTransform(dst, src) 
    #     self.warp_size = (width,h)
    #     self.orig_size = (width, height)
        


    def warp(self,img, filename):
        img_persp = img.copy()

        cv2.line(img_persp, self.perspective_dest[0], self.perspective_dest[1], (255, 255, 255), 3)
        cv2.line(img_persp, self.perspective_dest[1], self.perspective_dest[2], (255, 255, 255), 3)
        cv2.line(img_persp, self.perspective_dest[2], self.perspective_dest[3], (255, 255, 255), 3)
        cv2.line(img_persp, self.perspective_dest[3], self.perspective_dest[0], (255, 255, 255), 3)

        cv2.line(img_persp, self.perspective_trapezoid[0], self.perspective_trapezoid[1], (0, 192, 0), 3)
        cv2.line(img_persp, self.perspective_trapezoid[1], self.perspective_trapezoid[2], (0, 192, 0), 3)
        cv2.line(img_persp, self.perspective_trapezoid[2], self.perspective_trapezoid[3], (0, 192, 0), 3)
        cv2.line(img_persp, self.perspective_trapezoid[3], self.perspective_trapezoid[0], (0, 192, 0), 3)

        save_dir(img_persp, "persp_", filename)

        return save_dir(cv2.warpPerspective(img, self.perspective_correction, self.warp_size, flags=cv2.INTER_LANCZOS4), "warp_",
                        filename)

    def edge_detection(self,channel, filename):
        edge_x = cv2.Scharr(channel, cv2.CV_64F, 1, 0,9)  # Edge detection using the Scharr operator
        # edge_x = cv2.Canny(channel,100,100)
        # soble_dx=cv2.Sobel(channel, cv2.CV_64F, 1, 0)
        # soble_dy=cv2.Sobel(channel, cv2.CV_64F, 0, 1)
        # edge_x=cv2.magnitude(soble_dx,soble_dy)
        # soble_mag=np.clip(soble_mag,0,255)
        # soble_mag=np.clip(soble_mag)
        # edge_x=cv2.Laplacian(channel,cv2.CV_64F,-1,scale=10)
        edge_x = np.absolute(edge_x)
        cv2.imshow("canny",edge_x)
        # cv2.waitKey(0)

        # return save_dir(np.uint8(255 * edge_x / np.max(edge_x)), "edge_", filename)
        return edge_x


    def threshold(self,channel_threshold, channel_edge, filename):
        # Gradient threshold
        binary = np.zeros_like(channel_edge)
        height = binary.shape[0]

        threshold_up = 220
        threshold_down = 240
        
        threshold_delta = threshold_down - threshold_up

        for y in range(height):
            binary_line = binary[y, :]
            edge_line = channel_edge[y, :]
            threshold_line = threshold_up + threshold_delta * y / height
            binary_line[edge_line >= threshold_line] = 255

        save_dir(binary, "threshold_edge_only_", filename)
        save_dir(channel_threshold, "channel_only_", filename)

        thresholds = (channel_threshold <10) \
    

        # binary[(channel_threshold >= 140) & (channel_threshold <= 255)] = 255
        # binary[thresholds]=0
        # binary[~thresholds]=255
        binary_threshold = np.zeros_like(channel_threshold)
        cv2.imshow("binary",binary)
        binary_threshold[(channel_threshold >= 140) & (channel_threshold <= 255)] = 255

        return (save_dir(binary, "threshold_", filename), save_dir(binary, "threshold_other", filename))


    def histogram(self,img, prefix, filename):
        partial_img = img[img.shape[0] * 2 // 3:, :]  # Select the bottom part (one third of the image)
        hist = np.sum(partial_img, axis=0)

        if get_save_files() and filename:
            plt.plot(hist)
            plt.draw()
            plt.pause(0.01)
            plt.savefig(ensure_dir(filename) + "/" + prefix + filename.replace(".jpg", ".png"))
            plt.clf()

        return hist


    def avg_x(self,hist_lanes):
        
        return sum([lane.hist_x for lane in hist_lanes]) // len(hist_lanes)




    def slide_window(self,img, binary_warped, hist, num_windows, filename=None, prefix=None):
        img_height = binary_warped.shape[0]
        window_height = np.int(img_height / num_windows)
        # Indices (e.g. coordinates) of the pixels that are not zero
        non_zero = binary_warped.nonzero()
        non_zero_y = np.array(non_zero[0])
        non_zero_x = np.array(non_zero[1])
        # Current positions, to be updated while sliding the window; we start with the ones identified with the histogram
        left_x = hist.x_left
        right_x = hist.x_right
  

        margin = 40
        # Set minimum number of pixels found to recenter window
        min_pixels = 25
        left_lane_indexes = []
        right_lane_indexes = []

        out_img = img.copy() if (filename and prefix) else None

        for idx_window in range(num_windows):
            # X range where we expect the left lane to land
            win_x_left_min = left_x - margin
            win_x_left_max = left_x + margin
            # X range where we expect the right lane to land
            win_x_right_min = right_x - margin
            win_x_right_max = right_x + margin
            # Y range that we are analyzing
            win_y_top = img_height - idx_window * window_height
            win_y_bottom = win_y_top - window_height

            # Show the windows
            if (filename and prefix):
                cv2.rectangle(out_img, (win_x_left_min, win_y_bottom), (win_x_left_max, win_y_top), (255, 255, 255), 2)
                cv2.rectangle(out_img, (win_x_right_min, win_y_bottom), (win_x_right_max, win_y_top), (255, 255, 255), 2)

            # Non zero pixels in x and y
            non_zero_left = ((non_zero_y >= win_y_bottom) & (non_zero_y < win_y_top) & (non_zero_x >= win_x_left_min) & (
                    non_zero_x < win_x_left_max)).nonzero()[0]
            non_zero_right = ((non_zero_y >= win_y_bottom) & (non_zero_y < win_y_top) & (non_zero_x >= win_x_right_min) & (
                    non_zero_x < win_x_right_max)).nonzero()[0]

            left_lane_indexes.append(non_zero_left)
            right_lane_indexes.append(non_zero_right)
            # If you found > min_pixels pixels, recenter next window on the mean position
            if len(non_zero_left) > min_pixels:
                left_x = np.int(np.mean(non_zero_x[non_zero_left]))

            if len(non_zero_right) > min_pixels:
                right_x = np.int(np.mean(non_zero_x[non_zero_right]))

            

        valid, sw = self.fit_slide_window(binary_warped, hist, left_lane_indexes, right_lane_indexes, non_zero_x, non_zero_y)
        if valid and filename and prefix and get_save_files():
            out_img[non_zero_y[sw.left.lane_indexes], non_zero_x[sw.left.lane_indexes]] = [255]
            out_img[non_zero_y[sw.right.lane_indexes], non_zero_x[sw.right.lane_indexes]] = [255]
            img_plot = sw.plot_lines(out_img)
            cv2.imshow("window",img_plot)

            cv2.imwrite(ensure_dir(filename) + "/" + prefix + filename, img_plot)
        return valid, sw


    def moving_average(self,prev_average, new_value, beta):
        return beta * prev_average + (1 - beta) * new_value if prev_average is not None else new_value


    def fit_slide_window(self,binary_warped, hist, left_lane_indexes, right_lane_indexes, non_zero_x, non_zero_y):
        sw = SlideWindow(hist, left_lane_indexes, right_lane_indexes, non_zero_x, non_zero_y)
        sw.hist= hist
        # y coordinates
        sw.ploty = np.array([float(x) for x in range(binary_warped.shape[0])])

        if len(sw.left.y) == 0 or len(sw.right.y)==0:
            return False, sw

        # Fit a second order polynomial to approximate the points
        left_fit = np.polynomial.polynomial.polyfit(sw.left.y, sw.left.x, 2)
        right_fit = np.polynomial.polynomial.polyfit(sw.right.y, sw.right.x, 2)


        self.left_fit_avg = self.moving_average(self.left_fit_avg, left_fit, 0.7)
        self.right_fit_avg = self.moving_average(self.right_fit_avg, right_fit, 0.7)
        # print(self.left_fit_avg,self.right_fit_avg)

        # Generate list of x and y values, using the terms of the polynomial
        # x = Ay^2 + By + C;
        sw.left.fitx = self.left_fit_avg[2] * sw.ploty ** 2 + self.left_fit_avg[1] * sw.ploty + self.left_fit_avg[0]
        sw.right.fitx = self.right_fit_avg[2] * sw.ploty ** 2 + self.right_fit_avg[1] * sw.ploty + self.right_fit_avg[0]
        

        ##make center value
        w=self.lane_width
        a= -2*w*self.left_fit_avg[2]/((4*(self.left_fit_avg[2]**2)+1)**0.5)
        b= w/((4*(self.left_fit_avg[2]**2)+1)**0.5)
        # sw.left_center.fitx =(self.left_fit_avg[2]) * (sw.ploty -a)** 2 + (self.left_fit_avg[1])* (sw.ploty-a)+ self.left_fit_avg[0]+b
        # sw.right_center.fitx =(self.right_fit_avg[2]) * (sw.ploty +a)** 2 + (self.right_fit_avg[1])* (sw.ploty+a)+ self.right_fit_avg[0]-b
        # if(hist.left_confidence <3000 and hist.right_confidence<3000):
        #     print("Not  detected line")
        #     return False, sw
        if (hist.left_confidence >hist.right_confidence*1.5):
            sw.main_center.fitx = (self.left_fit_avg[2]) * (sw.ploty -a)** 2 + (self.left_fit_avg[1])* (sw.ploty-a)+ self.left_fit_avg[0]+b
        elif (hist.left_confidence*1.5 <=hist.right_confidence):
            sw.main_center.fitx = (self.right_fit_avg[2]) * (sw.ploty +a)** 2 + (self.right_fit_avg[1])* (sw.ploty+a)+ self.right_fit_avg[0]-b
        else:
            sw.main_center.fitx = ((self.right_fit_avg[2]) * (sw.ploty +a)** 2 + (self.right_fit_avg[1])* (sw.ploty+a)+ self.right_fit_avg[0]-b+(self.left_fit_avg[2]) * (sw.ploty -a)** 2 + (self.left_fit_avg[1])* (sw.ploty-a)+ self.left_fit_avg[0]+b)/2

        # sw.main_center.fitx = (sw.left_center.fitx+ sw.right_center.fitx)/2
        
        # print( sw.main_center.fitx)
        return True, sw
    
    def find_next_point(self):
        y=self.lookahead
        if len(self.sw.main_center.fitx) != 0:
            x=self.sw.main_center.fitx[y]
            cv2.circle(self.wraped_lane, (int(x),int(y)),10,(0,255,255),-1)
            cv2.circle(self.wraped_lane, (self.middle,self.height),10,(255,255,0),-1)
            cv2.imshow("final",self.wraped_lane)
        return 


    def show_lanes(self,sw, img_warped, img_orig, filename):
        img = img_warped.copy()

        if sw.left:
            fitx_points_warped = np.float32([np.transpose(np.vstack([sw.left.fitx, sw.ploty]))])
            fitx_points = cv2.perspectiveTransform(fitx_points_warped, self.perspective_correction_inv)
            left_line_warped = np.int_(fitx_points_warped[0])
            left_line = np.int_(fitx_points[0])
            n = len(left_line)

            for i in range(n - 1):
                cv2.line(img_orig, (left_line[i][0], left_line[i][1]), (left_line[i + 1][0], left_line[i + 1][1]),
                        (0, 255, 0), 5)
                cv2.line(img, (left_line_warped[i][0], left_line_warped[i][1]),
                        (left_line_warped[i + 1][0], left_line_warped[i + 1][1]), (0, 255, 0), 5)

        if sw.right :
            fitx_points_warped = np.float32([np.transpose(np.vstack([sw.right.fitx, sw.ploty]))])
            fitx_points = cv2.perspectiveTransform(fitx_points_warped, self.perspective_correction_inv)
            right_line_warped = np.int_(fitx_points_warped[0])
            right_line = np.int_(fitx_points[0])

            for i in range(len(right_line) - 1):
                cv2.line(img_orig, (right_line[i][0], right_line[i][1]), (right_line[i + 1][0], right_line[i + 1][1]),
                        (0, 0, 255), 5)
                cv2.line(img, (right_line_warped[i][0], right_line_warped[i][1]),
                        (right_line_warped[i + 1][0], right_line_warped[i + 1][1]), (0, 0, 255), 5)
                
        if len(sw.left_center.fitx) !=0: 
            fitx_points_warped = np.float32([np.transpose(np.vstack([sw.left_center.fitx, sw.ploty]))])
            fitx_points = cv2.perspectiveTransform(fitx_points_warped, self.perspective_correction_inv)
            right_line_warped = np.int_(fitx_points_warped[0])
            right_line = np.int_(fitx_points[0])

            for i in range(len(right_line) - 1):
                cv2.line(img_orig, (right_line[i][0], right_line[i][1]), (right_line[i + 1][0], right_line[i + 1][1]),
                        (0, 100, 255), 5)
                cv2.line(img, (right_line_warped[i][0], right_line_warped[i][1]),
                        (right_line_warped[i + 1][0], right_line_warped[i + 1][1]), (0, 100, 255), 5)
        
        if len(sw.right_center.fitx) !=0: 
                fitx_points_warped = np.float32([np.transpose(np.vstack([sw.right_center.fitx, sw.ploty]))])
                fitx_points = cv2.perspectiveTransform(fitx_points_warped, self.perspective_correction_inv)
                right_line_warped = np.int_(fitx_points_warped[0])
                right_line = np.int_(fitx_points[0])

                for i in range(len(right_line) - 1):
                    cv2.line(img_orig, (right_line[i][0], right_line[i][1]), (right_line[i + 1][0], right_line[i + 1][1]),
                            (0, 100, 255), 5)
                    cv2.line(img, (right_line_warped[i][0], right_line_warped[i][1]),
                            (right_line_warped[i + 1][0], right_line_warped[i + 1][1]), (0, 100, 255), 5)
                    
        if len(sw.main_center.fitx) !=0: 
                fitx_points_warped = np.float32([np.transpose(np.vstack([sw.main_center.fitx, sw.ploty]))])
                fitx_points = cv2.perspectiveTransform(fitx_points_warped, self.perspective_correction_inv)
                right_line_warped = np.int_(fitx_points_warped[0])
                right_line = np.int_(fitx_points[0])

                for i in range(len(right_line) - 1):
                    try:
                        cv2.line(img_orig, (right_line[i][0], right_line[i][1]), (right_line[i + 1][0], right_line[i + 1][1]),
                                (255, 100, 255), 5)
                        cv2.line(img, (right_line_warped[i][0], right_line_warped[i][1]),
                                (right_line_warped[i + 1][0], right_line_warped[i + 1][1]), (255, 100, 255), 5)
                    except:
                        print("drawing error")
                        
                        
                
            
        cv2.imshow("lanes",img)
        self.wraped_lane=img
        save_dir(img, "lanes_warped_", filename)

        return save_dir(img_orig, "lanes_orig_", filename)


    def lanes_full_histogram(self,histogram):
        size = len(histogram)
        
        max_index_left = np.argmax(histogram[0:318])
        max_index_right = np.argmax(histogram[320:]) + 320

        return HistLanes(max_index_left, max_index_right, histogram[max_index_left], histogram[max_index_right])


    def lanes_partial_histogram(self,histogram, left_lanes, right_lanes, tolerance):
        max_index_left = self.partial_lane(histogram, left_lanes, tolerance)
        max_index_right = self.partial_lane(histogram, right_lanes, tolerance)

        return HistLanes(max_index_left, max_index_right, histogram[max_index_left], histogram[max_index_right])


    def partial_lane(self,histogram, lanes_previous_frames, tolerance):
        lane_avg = self.avg_x(lanes_previous_frames)
        lane_min = max(lane_avg - tolerance, 0)
        lane_max = min(lane_avg + tolerance, len(histogram))

        return np.argmax(histogram[lane_min:lane_max]) + lane_min


    def detect_lanes(self,img_bgr, filename):
        # img_bgr = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HLS).astype(np.float)
        # b,g,r = cv2.split(img_bgr)                     # 채널 별로 분리 ---②
        # gray1 = ((b + g + r)/3).astype(np.uint8)    # 평균 값 연산후 dtype 변경 ---③
        # gray2 = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY) # BGR을 그레이 스케일로 변경 ---④


        img_warped = cv2.warpPerspective(img_bgr, self.perspective_correction, (self.width, self.height),flags=cv2.INTER_LANCZOS4)
        plt.ion()
        # img_warped = self.warp(img_bgr, filename)
        cv2.imshow('wraped',img_warped[:,:])

        img_edge = self.edge_detection(img_warped[:, :,1], filename)
        img_HSL=cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HLS).astype(np.float)
        (img_binary_combined, img_binary_solo) = self.threshold(img_HSL[:,:,2], img_edge, filename)

        # cv2.imshow('image channel H',img_bgr)
        # cv2.imshow('image channel L')
        # cv2.imshow('image channel S')

    
        hist = self.histogram(img_binary_combined, "hist_", filename)
        self.histogram(img_binary_solo, "hist_solo_", filename)

        if (len(self.left_lanes) > MIN_DETECTIONS):
            lanes = self.lanes_partial_histogram(hist, self.left_lanes, self.right_lanes, 30)
        else:
            lanes = self.lanes_full_histogram(hist)
        
        # lines = cv2.HoughLines(img_binary_combined, 1, np.pi / 180, 150, None, 0, 0)
        
         
        # if lines is not None:
        #     for i in range(0, len(lines)):
        #         rho = lines[i][0][0]
        #         theta = lines[i][0][1]
        #         print("%.2f"%theta)
                
                

        ret, sw = self.slide_window(img_warped, img_binary_combined, lanes, 15, filename, prefix="window_")

        if ret:
            self.left_lanes.append(deepcopy(sw.left))
            self.right_lanes.append(deepcopy(sw.right))
        else:
            if len(self.left_lanes) != 0:
            # In case of problems, use the previous detection
                sw.left = self.left_lanes[len(self.left_lanes) - 1]
                sw.right = self.right_lanes[len(self.right_lanes) - 1]

                self.left_lanes.append(sw.left)
                self.right_lanes.append(sw.right)
            
        # print(left_lanes,right_lanes)
        # print(self.left_lanes)

        img_lane = self.show_lanes(sw, img_warped, img_bgr, filename)
        cv2.imshow('lane',img_lane)
        self.sw=sw
        return img_lane


    def reset():
        global left_fit_avg, right_fit_avg

        left_fit_avg = None
        right_fit_avg = None
# reset()
# img = cv2.imread("test_images_sd/" + filename)
if __name__=="__main__":
    pt1 = np.float32([[81,325],[241,267],[479,261],[633,314]])
    ld=LaneDetecter()
    ld.compute_perspective(width,height,pt1[0],pt1[1],pt1[2],pt1[3])
    img = cv2.imread("/home/xytron/xycar_ws/data/perspective_view/frame0831.jpg")
    frame=ld.detect_lanes(img, 'test.jpg', [], [])
    n = 0
    left_lanes = []
    right_lanes = []

    cv2.imshow('frame',frame)
    cv2.imshow(win_name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()